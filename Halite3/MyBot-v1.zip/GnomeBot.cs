using Halite3.Hlt;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Diagnostics;

namespace Halite3
{
    public enum ShipState
    {
        None = 0,
        Headed,
        Mining,
        Returning
    }

    public sealed class ShipStatus
    {
        public ShipState State { get; set; }
    }

    public sealed class GnomeBot
    {
        public static void Main(string[] args)
        {
            //while (!Debugger.IsAttached);

            int rngSeed = args.Length > 1 ? int.Parse(args[1], CultureInfo.InvariantCulture) : DateTime.Now.Millisecond;
            var rng = new Random(rngSeed);

            var game = new Game();
            // At this point "game" variable is populated with initial map data.
            // This is a good place to do computationally expensive start-up pre-processing.
            // As soon as you call "ready" function below, the 2 second per turn timer will start.
            Game.Ready("MyCSharpBot");

            Log.LogMessage("Successfully created bot! My Player ID is " + game.MyId + ". Bot rng seed is " + rngSeed + ".");

            var foo = new Dictionary<EntityId, ShipStatus>();

            for (; ; )
            {
                game.UpdateFrame();

                if (InitialSpawn(game))
                    continue;

                var commandQueue = new List<Command>();

                foreach (Ship ship in game.Me.Ships.Values)
                {
                    if (!foo.TryGetValue(ship.Id, out ShipStatus status))
                        foo.Add(ship.Id, status = new ShipStatus { State = ShipState.None });

                    switch (status.State)
                    {
                        case ShipState.None:
                        case ShipState.Mining:
                            {
                                if (ship.IsFull)
                                {
                                    foo[ship.Id].State = ShipState.Returning;
                                    goto case ShipState.Returning;
                                }

                                if (game.Map.At(ship.Position).Halite > Constants.BarrenHalite)
                                {
                                    foo[ship.Id].State = ShipState.Mining;
                                    commandQueue.Add(ship.Stay());
                                    continue;
                                }

                                Position pos = ship.Position;
                                var best = 0;
                                while (best == 0)
                                {
                                    foreach (Direction dir in DirectionExtensions.AllCardinals)
                                    {
                                        Position pos1 = ship.Position.DirectionalOffset(dir);
                                        if (game.Map.At(pos1).Halite > best
                                            && game.Map.At(pos1).IsEmpty)
                                        {
                                            best = game.Map.At(pos1).Halite;
                                            pos = pos1;
                                        }
                                    }

                                    if (best == 0)
                                    {
                                        foreach (Direction dir in DirectionExtensions.AllCardinals)
                                        {
                                            Position pos1 = ship.Position.DirectionalOffset(dir);
                                            if (game.Map.At(pos1).IsEmpty)
                                            {
                                                pos = pos1;
                                            }
                                        }
                                    }

                                    if (pos != ship.Position)
                                    {
                                        Direction dir = game.Map.NaiveNavigate(ship, pos);
                                        commandQueue.Add(ship.Move(dir));
                                    }
                                }

                            }
                            break;

                        case ShipState.Returning:
                            {
                                if (ship.Position == game.Me.Shipyard.Position)
                                {
                                    foo[ship.Id].State = ShipState.None;
                                    goto case ShipState.None;
                                }

                                Position pos = game.Me.Shipyard.Position;
                                int best = game.Map.CalculateDistance(ship.Position, pos);
                                foreach (Dropoff dropoff in game.Me.Dropoffs.Values)
                                {
                                    var dist = game.Map.CalculateDistance(ship.Position, dropoff.Position);
                                    if (dist <= best)
                                    {
                                        pos = dropoff.Position;
                                        best = dist;
                                    }
                                }

                                Direction dir = game.Map.NaiveNavigate(ship, pos);
                                commandQueue.Add(ship.Move(dir));
                            }
                            break;
                    }
                }

                if (
                    game.TurnNumber <= 200 &&
                    game.Me.Halite > 1.5 * Constants.ShipCost &&
                    !game.Map.At(game.Me.Shipyard).IsOccupied)
                {
                    commandQueue.Add(Shipyard.Spawn());
                }

                Game.EndTurn(commandQueue);
            }
        }

        private static bool InitialSpawn(Game game)
        {
            if (game.TurnNumber >= 6)
                return false;

            var commands = new List<Command>(5);
            foreach (Ship ship in game.Me.Ships.Values)
            {
                if (ship.Position == game.Me.Shipyard.Position)
                {
                    var dir = (Direction)("nesw"[game.TurnNumber - 2]);
                    commands.Add(ship.Move(dir));
                }
            }

            if (game.TurnNumber <= 4)
                commands.Add(Shipyard.Spawn());

            Game.EndTurn(commands);
            return true;
        }
    }
}
