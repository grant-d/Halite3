namespace Halite3.Hlt
{
#pragma warning disable CA1028 // Enum Storage should be Int32
    public enum FlowDirection : byte
#pragma warning restore CA1028 // Enum Storage should be Int32
    {
        _ = 0,

        N,
        E,
        S,
        W,
    }
}
